package classwork;

public class Multithreading 
{
	public static void main(String args[])
	{
		
	}
}
