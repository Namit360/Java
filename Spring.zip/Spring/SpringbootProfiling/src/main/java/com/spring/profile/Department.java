package com.spring.profile;
import org.springframework.stereotype.Component;

@Component
public interface Department 
{
	public void runConfiguration();
}
