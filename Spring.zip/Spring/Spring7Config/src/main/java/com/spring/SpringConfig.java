package com.spring;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = "com.spring")
public class SpringConfig
{
	@Bean(name="customer") public Customer customerBean() 
	{ 
	  Customer cust=new Customer(); 
	  cust.setCustId(100); 
	  cust.setCustName("ABC"); 
	  return cust; 
	}
}