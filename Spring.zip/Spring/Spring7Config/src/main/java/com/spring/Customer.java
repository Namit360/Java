package com.spring;
import org.springframework.stereotype.Component;

@Component("customer")
public class Customer
{
	int custId;
	String custName;
	
	Customer()
	{
		System.out.println("Object Created");
	}
	
	public Customer(int custId, String custName)
	{
		this.custId = custId;
		this.custName = custName;
	}

	public int getCustId() 
	{
		return custId;
	}
	public void setCustId(int custId)
	{
		this.custId = custId;
	}
	public String getCustName() 
	{
		return custName;
	}
	public void setCustName(String custName)
	{
		this.custName = custName;
	}
	@Override
	public String toString()
	{
		return "Customer [custId=" + custId + ", custName=" + custName + "]";
	}
}