package com.spring;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class Customer implements InitializingBean, DisposableBean 
{
	int custId;
	String custName;
	
	Customer()
	{
		System.out.println("Object Created");
	}
	
	public Customer(int custId, String custName) 
	{
		this.custId = custId;
		this.custName = custName;
	}

	public int getCustId()
	{
		return custId;
	}
	
	public void setCustId(int custId)
	{
		this.custId = custId;
	}
	public String getCustName() 
	{
		return custName;
	}
	public void setCustName(String custName) 
	{
		this.custName = custName;
	}

	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", custName=" + custName + "]";
	}
	
	public void destroy() throws Exception
	{
		System.out.println("destroy method");
	}
	
	public void afterPropertiesSet() throws Exception
	{
		System.out.println("after injection");
	}
}