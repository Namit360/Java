package com.spring.service;

public interface ProductService 
{
	public String findbyId();
	public String findbyName();
	
}