package com.spring;

public class Customer 
{
	int custID;
	String custName;
	Address address;
	
	public Customer() 
	{
		System.out.println("object created");
	}
	
	public Customer(int custID, String custName, Address address)
	{
		this.custID = custID;
		this.custName = custName;
		this.address = address;
	}
	
	public void setCustID(int custID)
	{
		this.custID = custID;
	}
	
	public int getCustID()
	{
		return custID;
	}
	
	public void setCustName(String custName)
	{
		this.custName = custName;
	}
	
	public String getCustName()
	{
		return custName;
	}
	
	public void setAddress(Address address) 
	{
		this.address = address;
	}
	
	public Address getAaddress()
	{
		return address;
	}

	@Override
	public String toString() {
		return "Customer [custID=" + custID + ", custName=" + custName + ", address=" + address + "]";
	}
}
