package com.spring;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
	public static void main(String args[])
	{
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml"); // Customer
		Customer customer = context.getBean("cust", Customer.class);
		customer.setCustId(100);
		customer.setCustName("Alex");
		System.out.println(customer);
		Customer customer2 = context.getBean("cust", Customer.class);
		customer2.setCustId(101);
		customer2.setCustName("Anna");
		System.out.println(customer2);
	}
}