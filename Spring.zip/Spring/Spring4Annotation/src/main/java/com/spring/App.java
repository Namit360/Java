package com.spring;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

public class App 
{
	public static void main(String args[])
	{
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml"); // Customer
		Customer customer = context.getBean("cust1", Customer.class);
		System.out.println(customer);
		
		/*
		 * ApplicationContext context1 = new
		 * ClassPathXmlApplicationContext("spring.xml"); Customer cust1 =
		 * context1.getBean("cust1",Customer.class); System.out.println(cust1);
		 */
		 
		/*
		 * Address person = context.getBean("per",Address.class);
		 * System.out.println(person);
		 */
	}
}