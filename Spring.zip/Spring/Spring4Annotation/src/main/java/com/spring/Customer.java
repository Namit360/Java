package com.spring;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Primary;

public class Customer 
{
	int custId;
	String custName;

	@Autowired
	@Qualifier("add1")
	Address address;
	
	Customer()
	{
		System.out.println("Object Created");
	}
	
	@Autowired
	public Customer(@Qualifier("add1") int custId, String custName, Address address) 
	{
		this.custId = custId;
		this.custName = custName;
		this.address = address;
	}

	public Address getAddress() 
	{
		return address;
	}
	
	public void setAddress(Address address) 
	{
		this.address = address;
	}

	public int getCustId()
	{
		return custId;
	}
	
	public void setCustId(int custId)
	{
		this.custId = custId;
	}
	public String getCustName() 
	{
		return custName;
	}
	public void setCustName(String custName) 
	{
		this.custName = custName;
	}

	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", custName=" + custName + ", address=" + address + "]";
	}
}