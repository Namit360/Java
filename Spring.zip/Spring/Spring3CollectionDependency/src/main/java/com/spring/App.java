package com.spring;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
	public static void main(String args[])
	{
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		Customer cust = context.getBean("cust",Customer.class);
		System.out.println(cust);
		
		ApplicationContext context1 = new ClassPathXmlApplicationContext("spring.xml");
		Customer cust1 = context1.getBean("cust1",Customer.class); 
		System.out.println(cust1);
		 
		/*
		 * Address person = context.getBean("per",Address.class);
		 * System.out.println(person);
		 */
	}
}