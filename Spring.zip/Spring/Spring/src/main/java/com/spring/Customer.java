package com.spring;

public class Customer 
{
	int custID;
	String custName;
	
	public Customer() {}
	
	public Customer(int custID, String custName)
	{
		this.custID = custID;
		this.custName = custName;
	}
	
	public void setCustID(int custID)
	{
		this.custID = custID;
	}
	
	public int getCustID()
	{
		return custID;
	}
	
	public void setCustName(String custName)
	{
		this.custName = custName;
	}
	
	public String getCustName()
	{
		return custName;
	}

	@Override
	public String toString() {
		return "Customer [custID=" + custID + ", custName=" + custName + "]";
	}
}
